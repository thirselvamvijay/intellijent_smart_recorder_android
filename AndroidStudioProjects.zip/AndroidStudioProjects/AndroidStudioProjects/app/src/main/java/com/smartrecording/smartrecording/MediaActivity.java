package com.smartrecording.smartrecording;

import android.app.Activity;
import android.os.Bundle;

public class MediaActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);
    }
}
